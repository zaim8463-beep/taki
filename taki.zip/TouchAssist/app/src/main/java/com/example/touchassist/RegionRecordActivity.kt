package com.example.touchassist

import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.util.DisplayMetrics
import android.view.WindowManager
import android.widget.Toast
import kotlin.math.max
import kotlin.math.min
import java.util.UUID

/** تسجيل المنطقة يستخدم نفس RecorderView وإعدادات العرض الخاصة بتسجيل الإيماءة. */
class RegionRecordActivity : Activity() {

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = lp
        }
        hideBars()
        val dm = DisplayMetrics()
        windowManager.defaultDisplay.getRealMetrics(dm)
        setContentView(RecorderView(
            this, dm.widthPixels, dm.heightPixels,
            onSave = { gesture ->
                val points = gesture.strokes.flatMap { it.points }
                if (points.isEmpty()) {
                    Toast.makeText(this, "حدد المنطقة أولاً", Toast.LENGTH_SHORT).show()
                } else {
                    // نحفظ كل خط كما رُسم. لا نحوّله إلى مستطيل؛ المستطيل أدناه مجرد حدود نافذة الرسم.
                    val contours = gesture.strokes
                        .map { stroke -> stroke.points.map { Pt(it.x, it.y, it.t) } }
                        .filter { it.size >= 3 }
                    val pad = 12f
                    val region = TouchRegion(
                        UUID.randomUUID().toString(), "",
                        max(0f, points.minOf { it.x } - pad),
                        max(0f, points.minOf { it.y } - pad),
                        min(dm.widthPixels.toFloat(), points.maxOf { it.x } + pad),
                        min(dm.heightPixels.toFloat(), points.maxOf { it.y } + pad),
                        dm.widthPixels, dm.heightPixels,
                        contours = contours
                    )
                    RegionEditActivity.pending = region
                    startActivity(Intent(this, RegionEditActivity::class.java))
                    finish()
                }
            },
            onCancel = { finish() },
            light = true
        ))
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideBars()
    }

    @Suppress("DEPRECATION")
    private fun hideBars() {
        window.decorView.systemUiVisibility =
            android.view.View.SYSTEM_UI_FLAG_FULLSCREEN or
                android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
    }
}
